<!-- Begin Page Content -->
  <div class="container-fluid">
    <!-- Page Heading -->
    <?php
	//ambil data isi yg ada di controller
	if($isi){
		$this->load->view($isi);
	}
	?>

  </div>
  <!-- /.container-fluid -->

  </div>
<!-- End of Main Content -->